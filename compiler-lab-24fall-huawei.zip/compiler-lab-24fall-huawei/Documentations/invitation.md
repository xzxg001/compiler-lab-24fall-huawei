## gitee 邀请其他用户参与项目

在仓库页面-管理-仓库成员管理菜单下，点击右上角的添加仓库成员-邀请用户。

![invatition-1.png](./common/figs/invitation-1.png)

邀请用户时可以通过链接，直接添加或通过仓库邀请成员。

在邀请时请注意用户的权限。

![invatition-2.png](./common/figs/invitation-2.png)

发出邀请后等待对面同意即可完成邀请。